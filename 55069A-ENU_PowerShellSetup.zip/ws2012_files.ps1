Remove-Item $Labfiles\Sources -Recurse -Force -ErrorAction SilentlyContinue
MD $Labfiles\Sources\Sxs -Force -Erroraction SilentlyContinue
DisMount-Diskimage -DevicePath \\.\CDROM1 -erroraction silentlycontinue
Mount-DiskImage $DCISO | Get-DiskImage
Copy-Item \\.\CDROM1\Sources\sxs -Destination $Labfiles\Sources -Recurse -PassThru -Force
DisMount-DiskImage $DCISO -PassThru
Copy-Item $DCISO $SRV1ISO -PassThru -Force
Copy-Item $DCISO $SRV2ISO -PassThru -Force