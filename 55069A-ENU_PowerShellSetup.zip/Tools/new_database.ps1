﻿function New-Database 
{
  <#
  .SYNOPSIS
  Use this function to create a new SQL Server database.
  .DESCRIPTION
  Use this function to create a new SQL Server database that inherits Autogrow & Maximum Size settings from the Model database.
  .EXAMPLE
  New-Database DB1
  .PARAMETER DatabaseName
  The name of the new database that will be created.
  .PARAMETER InstanceName
  The name of the SQL Server Instance on which the database will be created.
  #>
  [CmdletBinding()]
  param
  (
    [Parameter(Mandatory=$True,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True,
      HelpMessage='What is the name of the new database you are creating?')]
    [Alias('Name')]
    [ValidateLength(2,124)]
    [string[]]$DatabaseName,
    [Parameter(Mandatory=$True,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True,
      HelpMessage='What is the name of the SQL Server Instance on which the database will be created?')]
    [Alias('Instance')]
    [string[]]$InstanceName = $env:ComputerName
  )
‌
begin {
If ((Get-Module -List SQLPS)) {Echo "SQL Server Module already loaded"; Start-Sleep 3}
Else {Echo "SQL Server Module is loading, please wait..."; Import-Module SQLPS}
  }

process {
	# Create new database
    invoke-sqlcmd "Create Database $DatabaseName"

    # Get Database Settings for Model database
    $Server = new-object ('Microsoft.SQLServer.Management.Smo.Server') $InstanceName
    $Model = $Server.databases | where {$_.name -eq "model"}

    # Get Database Settings for $DatabaseName database
    $NewDB = $Server.databases | where {$_.name -eq $Databasename}

    # Apply Model database AutoGrow and Maximum size settings to $DatabaseName database
    $NewDB.logfiles[0].growthtype = $Model.logfiles[0].growthtype
    $NewDB.logfiles[0].growth = $Model.logfiles[0].growth
    $NewDB.logfiles[0].maxsize = $Model.logfiles[0].maxsize
    $NewDB.logfiles[0].alter()
    $NewDB.filegroups[0].files[0].growthtype = $Model.filegroups[0].files[0].growthtype
    $NewDB.filegroups[0].files[0].growth = $Model.filegroups[0].files[0].growth
    $NewDB.filegroups[0].files[0].maxsize = $Model.filegroups[0].files[0].maxsize
    $NewDB.filegroups[0].files[0].alter()
}

end {}

}