﻿# This script configures the Hyper-V Machines used for the 55066 Course.
# This script will only work on computers that run Hyper-V 2.0 and PowerShell 2.0.
# The Drive that corresponds to the $VMLOC variable should have at least 200GB of free space available.
# The Drive that corresponds to the $Labfiles variable should have at least 20GB of free space available.
# All the files for the 55066 Student CD should be copied to $Labfiles before running this script.

# Variables
$SRV2 = "55069-GEN-SR2"
$SRV1 = "55066-GEN-SR1"
$DC1 = "55066-GEN-DC1"
$SRRAM = 2GB
$DCRAM = 2GB
$SRVVHD = 120GB
$DCVHD = 120GB
$SRV1ISO = "C:\Labfiles\WS2012_SRV1.ISO"
$SRV2ISO = "C:\Labfiles\WS2012_SRV2.ISO"
$DCISO = "C:\Labfiles\WS2012.ISO"
$SQLISO = "C:\Labfiles\SQL2012.ISO"
$AdventureWorks = "C:\Labfiles\AdventureWorks 2012 OLTP Script.zip"
$Labfiles = "C:\Labfiles"
$VMLOC = "C:\HyperV"
$Network1 = "PrivateNetwork1"
$Network2 = "SharedNetwork1"
$VHDMP = "S:"
$7Z = "C:\Program Files\7-Zip\7z.exe"

# Load HyperV Module
Get-ChildItem $PSHome\Modules -Recurse | UnBlock-File -ErrorAction SilentlyContinue
$HyperV = Get-Module HyperV
if ($HyperV -eq $Null) {Import-Module HyperV -ErrorAction SilentlyContinue}

# Verify that the VMs do not already exist.
$VMSRV2 = Get-VM $SRV2 -ErrorAction SilentlyContinue; If ($VMSRV2) {echo "***   The $SRV2 VM already exists.  Please delete it and its resources before using this script.   ***"; Start-Sleep 15 ; exit}
$VMSRV1 = Get-VM $SRV1 -ErrorAction SilentlyContinue; If ($VMSRV1) {echo "***   The $SRV1 VM already exists.  Please delete it and its resources before using this script.   ***"; Start-Sleep 15 ; exit}
$VMDC1 = Get-VM $DC1 -ErrorAction SilentlyContinue; If ($VMDC1) {echo "***   The $DC1 VM already exists.  Please delete it and its resources before using this script.   ***"; Start-Sleep 15 ; exit}
$TPLabfiles = Test-Path $Labfiles ; If ($TPLabfiles -eq $False){cls ; "The $Labfiles folder does not exist." ; "Please verify the location of the classroom setup files." ; Start-Sleep 15 ; exit}
$TPSRV2HD1 = Test-Path $VMLOC\$SRV2.vhd ; If ($TPSRV2HD1 -eq $True){cls ; "The " + $SRV2 + " vhd already exists.  Verify that the VMs are not already configured." ; Start-Sleep 15 ; exit}
$TPSRV2HD2 = Test-Path $VMLOC\Labfiles_$SRV2.vhd ; If ($TPSRV2HD2 -eq $True){cls ; "The Labfiles_$SRV2 vhd already exists.  Verify that the VMs are not already configured." ; Start-Sleep 15 ; exit}
$TPSRV1HD1 = Test-Path $VMLOC\$SRV1.vhd ; If ($TPSRV1HD1 -eq $True){cls ; "The " + $SRV1 + " vhd already exists.  Verify that the VMs are not already configured." ; Start-Sleep 15 ; exit}
$TPSRV1HD2 = Test-Path $VMLOC\Labfiles_$SRV1.vhd ; If ($TPSRV1HD2 -eq $True){cls ; "The Labfiles_$SRV1 vhd already exists.  Verify that the VMs are not already configured." ; Start-Sleep 15 ; exit}
$TPDC1HD1 = Test-Path $VMLOC\$DC1.vhd ; If ($TPDC1HD1 -eq $True){cls ; "The " + $DC1 + " vhd already exists.  Verify that the VMs are not already configured." ; Start-Sleep 15 ; exit}
$TPDC1HD2 = Test-Path $VMLOC\Labfiles_$DC1.vhd ; If ($TPDC1HD2 -eq $True){cls ; "The Labfiles_$DC1 vhd already exists.  Verify that the VMs are not already configured." ; Start-Sleep 15 ; exit}
remove-vmswitch $Network1 -force -erroraction silentlycontinue
remove-vmswitch $Network2 -force -erroraction silentlycontinue
MD $VMLOC -erroraction silentlycontinue

# Create VMs and get MAC Addresses for Network Adapters
new-vmprivateswitch $Network1
new-vminternalswitch $Network2
$SRV2, $SRV1, $DC1 | new-vm -path $VMLOC
get-vm $SRV2, $SRV1, $DC1 | remove-vmnic -ErrorAction SilentlyContinue
get-vm $SRV2, $SRV1, $DC1 | remove-vmdrive -ControllerID 1 -LUN 0 -ErrorAction SilentlyContinue
get-vm $SRV2, $SRV1, $DC1 | add-vmnic -virtualswitch $Network1
get-vm $SRV2, $SRV1, $DC1 | add-vmnic -virtualswitch $Network2
get-vm $SRV2, $SRV1, $DC1 | set-vmcpucount -CPUCount 4
get-vm $SRV1 | set-vmmemory -Memory $SRRAM 
get-vm $DC1 | set-vmmemory -Memory $DCRAM 
get-vm $SRV2 | Start-VM
get-vm $SRV1 | Start-VM
get-vm $DC1 | Start-VM
Start-Sleep 10
$SRV2MAC=Get-VMNIC $SRV2 | Where {$_.SwitchName -eq $Network1} | Select Address | Convertto-csv; $SRV2MAC[2] | Out-File $Labfiles\$SRV2.txt
$SRV1MAC=Get-VMNIC $SRV1 | Where {$_.SwitchName -eq $Network1} | Select Address | Convertto-csv; $SRV1MAC[2] | Out-File $Labfiles\$SRV1.txt
$DC1MAC=Get-VMNIC $DC1 | Where {$_.SwitchName -eq $Network1} | Select Address | Convertto-csv; $DC1MAC[2] | Out-File $Labfiles\$DC1.txt
get-vm $SRV2 | Stop-VM -Force
Start-Sleep 5
get-vm $SRV1 | Stop-VM -Force
Start-Sleep 5
get-vm $DC1 | Stop-VM -Force

# Copy Windows Server 2012 Files Needed to Configure Windows Features on VM
echo "     *****     Copy Windows Server 2012 Files     *****"
$TPDCISO = Test-Path $DCISO ; If ($TPDCISO -eq $False){cls ; "The Windows Server 2012 Files could not be found at $DCISO.  Please check the setup instructions and start again." ; Start-Sleep 15 ; exit}
Start-Process -FilePath $7Z -ArgumentList "x $DCISO -r sources\sxs\*.* -o$Labfiles\ -y" -Wait -PassThru -ErrorAction Stop
Copy-Item $DCISO $SRV1ISO -PassThru -Force -ErrorAction Stop

# Copy SQL Server 2012 Files
echo "     *****     Copy SQL Server 2012 Setup Files and AdventureWorks Database     *****"
$TPSQLISO = Test-Path $SQLISO ; If ($TPSQLISO -eq $False){cls ; "The SQL Server 2012 Files could not be found at $SQLISO.  Please check the setup instructions and start again." ; Start-Sleep 15 ; exit}
Start-Process -FilePath $7Z -ArgumentList "x $SQLISO -r -o$Labfiles\SQLServer\SQL2012\ -y" -Wait -PassThru -ErrorAction Stop
Remove-Item -Recurse -Force "$Labfiles\AdventureWorks" -ErrorAction SilentlyContinue
Start-Process -FilePath $7Z -ArgumentList "x $AdventureWorks -r -o$Labfiles -y" -Wait -PassThru -ErrorAction Stop
Rename-Item "$Labfiles\AdventureWorks 2012 OLTP Script" "$Labfiles\AdventureWorks" -Force -ErrorAction SilentlyContinue

# Verify Setup Folders are named properly
$TPWS = Test-Path $Labfiles\Sources\SXS ; If ($TPWS -eq $False){cls ; "The Windows Server 2012 Files are not in $Labfiles\Sources\SXS.  Please check the setup instructions and start again." ; Start-Sleep 15 ; exit}
$TPSQL = Test-Path $Labfiles\SQLServer\SQL2012 ; If ($TPSQL -eq $False){cls ; "The SQL Server Files are not in $Labfiles\SQLServer\SQL2012.  Please check the setup instructions and start again." ; Start-Sleep 15 ; exit}
$TPAWDB = Test-Path $Labfiles\"AdventureWorks 2012 OLTP Script.zip"; If ($TPAWDB -eq $False){cls ; "The AdventureWorks 2012 OLTP Script.zip file was not found.  Please check the setup instructions and start again." ; Start-Sleep 15 ; exit}

# Create and Mount Drives and Controllers
echo "     *****     Create vhd used for Labfiles     *****" 
& $Labfiles\labfiles_HV2.ps1
new-vhd -vhdpaths $VMLOC\$SRV2.vhd -size $SRVVHD
new-vhd -vhdpaths $VMLOC\$SRV1.vhd -size $SRVVHD
new-vhd -vhdpaths $VMLOC\$DC1.vhd -size $DCVHD
Get-VM $SRV2, $SRV1, $DC1 | add-vmdrive -ControllerID 1 -LUN 0 -DVD
add-vmdisk -vm $DC1 -controllerid 0 -lun 0 -path $VMLOC\$DC1.vhd
add-vmdisk -vm $SRV1 -controllerid 0 -lun 0 -path $VMLOC\$SRV1.vhd
add-vmdisk -vm $SRV2 -controllerid 0 -lun 0 -path $VMLOC\$SRV2.vhd
add-vmdisk -vm $DC1 -controllerid 0 -lun 1 -path $VMLOC\Labfiles_$DC1.vhd
add-vmdisk -vm $SRV1 -controllerid 0 -lun 1 -path $VMLOC\Labfiles_$SRV1.vhd
add-vmdisk -vm $SRV2 -controllerid 0 -lun 1 -path $VMLOC\Labfiles_$SRV2.vhd
add-vmdisk -vm $DC1 -controllerid 1 -lun 0 -Path $DCISO -Optical
add-vmdisk -vm $SRV1 -controllerid 1 -lun 0 -Path $SRV1ISO -Optical
add-vmdisk -vm $SRV2 -controllerid 1 -lun 0 -Path $SRV2ISO -Optical
add-vmfloppydisk $DC1 $Labfiles\dc1install.vfd
add-vmfloppydisk $SRV1 $Labfiles\sr1install.vfd
add-vmfloppydisk $SRV2 $Labfiles\sr2install.vfd

# Configure VMs
start-vm $DC1
Timeout 600
start-vm $SRV1
Timeout 300
start-vm $SRV2

