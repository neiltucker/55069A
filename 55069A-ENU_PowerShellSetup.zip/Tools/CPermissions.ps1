takeown.exe /a /r /d y /f "C:\Program Files"
takeown.exe /a /r /d y /f "C:\Program Files (x86)"
icacls "C:\Program Files" /Grant System:F
icacls "C:\Program Files (x86)" /Grant System:F
icacls "C:\Program Files" /Grant Administrator:F
icacls "C:\Program Files (x86)" /Grant Administrator:F
