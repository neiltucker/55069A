﻿# This script configures the Hyper-V Machines used for the 55069 Course.
# This script will only work on computers that run Hyper-V 3.0 or higher and PowerShell 3.0 or higher.
# The Drive that corresponds to the $VMLOC variable should have at least 200GB of free space available.
# The Drive that corresponds to the $Labfiles variable should have at least 20GB of free space available.
# All the files for the 55069 Student CD should be copied to $Labfiles before running this script.

# Variables
$SRV2 = "55069-GEN-SR2"
$SRV1 = "55069-GEN-SR1"
$DC1 = "55069-GEN-DC1"
$SRRAM = 2GB
$DCRAM = 2GB
$SRVVHD = 120GB
$DCVHD = 120GB
$SRV1ISO = "C:\Labfiles\WS2012_SRV1.ISO"
$SRV2ISO = "C:\Labfiles\WS2012_SRV2.ISO"
$DCISO = "C:\Labfiles\WS2012.ISO"
$SQLISO = "C:\Labfiles\SQL2012.ISO"
$AdventureWorks = "C:\Labfiles\AdventureWorks 2012 OLTP Script.zip"
$Labfiles = "C:\Labfiles"
$VMLOC = "E:\HyperV"
$Network1 = "PrivateNetwork1"
$Network2 = "SharedNetwork1"
$VHDMP = "S:"

# Load HyperV Module
Get-ChildItem $PSHome\Modules -Recurse | UnBlock-File -ErrorAction SilentlyContinue
$HyperV = Get-Module Hyper-V
if ($HyperV -eq $Null) {Import-Module Hyper-V -ErrorAction SilentlyContinue}

# Verify that the VMs do not already exist.
$VMSRV2 = Get-VM $SRV2 -ErrorAction SilentlyContinue; If ($VMSRV2) {echo "***   The $SRV2 VM already exists.  Please delete it and its resources before using this script.   ***"; Start-Sleep 15 ; exit}
$VMSRV1 = Get-VM $SRV1 -ErrorAction SilentlyContinue; If ($VMSRV1) {echo "***   The $SRV1 VM already exists.  Please delete it and its resources before using this script.   ***"; Start-Sleep 15 ; exit}
$VMDC1 = Get-VM $DC1 -ErrorAction SilentlyContinue; If ($VMDC1) {echo "***   The $DC1 VM already exists.  Please delete it and its resources before using this script.   ***"; Start-Sleep 15 ; exit}
$TPLabfiles = Test-Path $Labfiles ; If ($TPLabfiles -eq $False){cls ; "The $Labfiles folder does not exist." ; "Please verify the location of the classroom setup files." ; Start-Sleep 15 ; exit}
$TPSRV2HD1 = Test-Path $VMLOC\$SRV2.vhdx ; If ($TPSRV2HD1 -eq $True){cls ; "The " + $SRV2 + " VHDX already exists.  Verify that the VMs are not already configured." ; Start-Sleep 15 ; exit}
$TPSRV2HD2 = Test-Path $VMLOC\Labfiles_$SRV2.vhdx ; If ($TPSRV2HD2 -eq $True){cls ; "The Labfiles_$SRV2 VHDX already exists.  Verify that the VMs are not already configured." ; Start-Sleep 15 ; exit}
$TPSRV1HD1 = Test-Path $VMLOC\$SRV1.vhdx ; If ($TPSRV1HD1 -eq $True){cls ; "The " + $SRV1 + " VHDX already exists.  Verify that the VMs are not already configured." ; Start-Sleep 15 ; exit}
$TPSRV1HD2 = Test-Path $VMLOC\Labfiles_$SRV1.vhdx ; If ($TPSRV1HD2 -eq $True){cls ; "The Labfiles_$SRV1 VHDX already exists.  Verify that the VMs are not already configured." ; Start-Sleep 15 ; exit}
$TPDC1HD1 = Test-Path $VMLOC\$DC1.vhdx ; If ($TPDC1HD1 -eq $True){cls ; "The " + $DC1 + " VHDX already exists.  Verify that the VMs are not already configured." ; Start-Sleep 15 ; exit}
$TPDC1HD2 = Test-Path $VMLOC\Labfiles_$DC1.vhdx ; If ($TPDC1HD2 -eq $True){cls ; "The Labfiles_$DC1 VHDX already exists.  Verify that the VMs are not already configured." ; Start-Sleep 15 ; exit}
remove-vmswitch $Network1 -force -erroraction silentlycontinue
remove-vmswitch $Network2 -force -erroraction silentlycontinue
MD $VMLOC -erroraction silentlycontinue

# Create VMs and get MAC Addresses for Network Adapters
new-vmswitch $Network1 -SwitchType Private
new-vmswitch $Network2 -SwitchType Internal
$SRV2, $SRV1, $DC1 | new-vm -path $VMLOC
get-vm $SRV2, $SRV1, $DC1 | remove-vmnetworkadapter -erroraction silentlycontinue
get-vm $SRV2, $SRV1, $DC1 | add-vmnetworkadapter -switchname $Network1
get-vm $SRV2, $SRV1, $DC1 | add-vmnetworkadapter -switchname $Network2
get-vm $SRV2, $SRV1, $DC1 | set-vmprocessor -Count 4 -Reserve 25 -Maximum 80
get-vm $SRV2, $SRV1 | set-vmmemory -dynamicmemoryenabled $true -MinimumBytes $SRRAM -StartupBytes $SRRAM -MaximumBytes 4GB
get-vm $DC1 | set-vmmemory -dynamicmemoryenabled $true -MinimumBytes $DCRAM -StartupBytes $DCRAM -MaximumBytes 4GB
get-vm $SRV2 | Start-VM
get-vm $SRV1 | Start-VM
get-vm $DC1 | Start-VM
Start-Sleep 10
$SRV2MAC=Get-VMNetworkAdapter $SRV2 | Where {$_.SwitchName -eq $Network1} | Select MacAddress | Convertto-csv; $SRV2MAC[2] | Out-File $Labfiles\$SRV2.txt
$SRV1MAC=Get-VMNetWorkAdapter $SRV1 | Where {$_.SwitchName -eq $Network1} | Select MacAddress | Convertto-csv; $SRV1MAC[2] | Out-File $Labfiles\$SRV1.txt
$DC1MAC=Get-VMNetWorkAdapter $DC1 | Where {$_.SwitchName -eq $Network1} | Select MacAddress | Convertto-csv; $DC1MAC[2] | Out-File $Labfiles\$DC1.txt
get-vm $SRV2 | Stop-VM -Turnoff -Force
Start-Sleep 5
get-vm $SRV1 | Stop-VM -Turnoff -Force
Start-Sleep 5
get-vm $DC1 | Stop-VM -Turnoff -Force

# Copy Windows Server 2012 Files Needed to Configure Windows Features on VM
echo "     *****     Copy Windows Server 2012 Files     *****"
$TPDCISO = Test-Path $DCISO ; If ($TPDCISO -eq $False){cls ; "The Windows Server 2012 Files could not be found at $DCISO.  Please check the setup instructions and start again." ; Start-Sleep 15 ; exit}
& $Labfiles\WS2012_Files.ps1

# Copy SQL Server 2012 Files
echo "     *****     Copy SQL Server 2012 Setup Files and AdventureWorks Database    *****"
$TPSQLISO = Test-Path $SQLISO ; If ($TPSQLISO -eq $False){cls ; "The SQL Server 2012 Files could not be found at $SQLISO.  Please check the setup instructions and start again." ; Start-Sleep 15 ; exit}
& $Labfiles\SQL2012_Files.ps1

# Verify Setup Folders are named properly
$TPWS = Test-Path $Labfiles\Sources\SXS ; If ($TPWS -eq $False){cls ; "The Windows Server 2012 Files are not in $Labfiles\Sources\SXS.  Please check the setup instructions and start again." ; Start-Sleep 15 ; exit}

$VerifySQL = 0
Do {
$TPSQL = Test-Path $Labfiles\SQLServer\SQL2012 ; If ($TPSQL -eq $True) {$VerifySQL = 4} `
Else {$VerifySQL++ ; echo "Trying to Rename SQL Server Setup Folder" ; Start-Sleep 5 ; `
Rename-Item $Labfiles\SQLServer\CDROM1 $Labfiles\SQLServer\SQL2012 -PassThru -Force -ErrorAction SilentlyContinue ;}
}
While ($VerifySQL -le 3)
$TPSQL = Test-Path $Labfiles\SQLServer\SQL2012 ; If ($TPSQL -eq $False){cls ; "The SQL Server Files are not in $Labfiles\SQLServer\SQL2012.  Please check the setup instructions and start again." ; Start-Sleep 15 ; exit}
$TPAWDB = Test-Path $Labfiles\"AdventureWorks 2012 OLTP Script.zip"; If ($TPAWDB -eq $False){cls ; "The AdventureWorks 2012 OLTP Script.zip file was not found.  Please check the setup instructions and start again." ; Start-Sleep 15 ; exit}

# Create and Mount Drives and Controllers
echo "     *****     Create VHDX used for Labfiles     *****" 
& $Labfiles\labfiles_HV3.ps1
new-vhd -path $VMLOC\$DC1.vhdx -size $DCVHD
new-vhd -path $VMLOC\$SRV1.vhdx -size $SRVVHD
new-vhd -path $VMLOC\$SRV2.vhdx -size $SRVVHD
add-vmharddiskdrive -vmname $DC1 -controllernumber 0 -controllertype ide -path $VMLOC\$DC1.VHDX
add-vmharddiskdrive -vmname $SRV1 -controllernumber 0 -controllertype ide -path $VMLOC\$SRV1.VHDX
add-vmharddiskdrive -vmname $SRV2 -controllernumber 0 -controllertype ide -path $VMLOC\$SRV2.VHDX
add-vmharddiskdrive -vmname $DC1 -controllernumber 0 -controllertype ide -path $VMLOC\Labfiles_$DC1.VHDX
add-vmharddiskdrive -vmname $SRV1 -controllernumber 0 -controllertype ide -path $VMLOC\Labfiles_$SRV1.VHDX
add-vmharddiskdrive -vmname $SRV2 -controllernumber 0 -controllertype ide -path $VMLOC\Labfiles_$SRV2.VHDX
remove-vmdvddrive -controllernumber 1 -controllerlocation 0 -vmname $DC1 -erroraction SilentlyContinue
remove-vmdvddrive -controllernumber 1 -controllerlocation 0 -vmname $SRV1 -erroraction SilentlyContinue
remove-vmdvddrive -controllernumber 1 -controllerlocation 0 -vmname $SRV2 -erroraction SilentlyContinue
add-vmdvddrive -controllernumber 1 -controllerlocation 0 -vmname $DC1 -Path $DCISO 
add-vmdvddrive -controllernumber 1 -controllerlocation 0 -vmname $SRV1 -Path $SRV1ISO 
add-vmdvddrive -controllernumber 1 -controllerlocation 0 -vmname $SRV2 -Path $SRV2ISO 
set-vmfloppydiskdrive $DC1 $Labfiles\dc1install.vfd
set-vmfloppydiskdrive $SRV1 $Labfiles\sr1install.vfd
set-vmfloppydiskdrive $SRV2 $Labfiles\sr2install.vfd

# Configure VMs
start-vm $DC1
Timeout 300
start-vm $SRV1
Timeout 300
start-vm $SRV2
