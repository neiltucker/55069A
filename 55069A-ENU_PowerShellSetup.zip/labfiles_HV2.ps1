# Generate the Scripts used by Diskpart.exe to manage the Labfiles.VHD file (LabfilesHD2A.txt & LabfilesHD2B.txt)
# Labfiles.vhd will be temporarily attached to the host server as the $VHDMP drive

cd $Labfiles
"create vdisk file " + $VMLOC + "\Labfiles_$DC1.vhd maximum=40960 type=expandable" | Out-File -encoding ASCII $Labfiles\LabfilesHD2A.txt
"select vdisk file " + $VMLOC + "\Labfiles_$DC1.vhd" | Out-File -encoding ASCII -append $Labfiles\LabfilesHD2A.txt
"attach vdisk" | Out-File -encoding ASCII -append $Labfiles\LabfilesHD2A.txt
"create partition primary" | Out-File -encoding ASCII -append $Labfiles\LabfilesHD2A.txt
"format quick label=Labfiles" | Out-File -encoding ASCII -append $Labfiles\LabfilesHD2A.txt
"assign letter=" + $VHDMP | Out-File -encoding ASCII -append $Labfiles\LabfilesHD2A.txt
"exit" | Out-File -encoding ASCII -append $Labfiles\LabfilesHD2A.txt
"select vdisk file $VMLOC\labfiles_$DC1.vhd" | Out-File -encoding ASCII $Labfiles\LabfilesHD2B.txt
"detach vdisk" | Out-File -encoding ASCII -append $Labfiles\LabfilesHD2B.txt
"exit" | Out-File -encoding ASCII -append $Labfiles\LabfilesHD2B.txt

# Create and mount the Labfiles vhd file
DISKPART.EXE /s $Labfiles\LabfilesHD2A.txt

# Copy class files to the Labfiles vhd drive
XCopy *.* $VHDMP\ /s/v/y/Exclude:exclude.txt

# Dismount the Labfiles vhd drive
DISKPART.EXE /s $Labfiles\LabfilesHD2B.txt

# Copy Labfiles.vhd
Copy $VMLOC\Labfiles_$DC1.vhd $VMLOC\Labfiles_$SRV1.vhd -Force -PassThru -ErrorAction Stop
Copy $VMLOC\Labfiles_$DC1.vhd $VMLOC\Labfiles_$SRV2.vhd -Force -PassThru -ErrorAction Stop