$SystemInfo = GWMI Win32_ComputerSystem 
$ProcessorInfo = GWMI Win32_Processor
$DriveInfo = Get-PSDrive C  
$Properties = @{
Name = $SystemInfo.Name
ProcessorType = $SystemInfo.SystemType
ProcessorSpeed_GHZ = [math]::Round($ProcessorInfo.MaxClockSpeed/1000,1)
SystemRAM_GB = [math]::Round($SystemInfo.TotalPhysicalMemory/1GB,1)
SystemDriveFreeSpace_GB = [math]::Round($DriveInfo.Free/1GB,1)
}
$SystemConfiguration = New-Object PSObject -Property $Properties

echo "***   Test Server Configuration before Install of SQL Server   ***"
echo ""
echo "Processor Type = x86 or x64"
echo "Minimum Processor Speed = 1.0 GHZ(x86) 1.4 GHZ(x64)"
echo "Minimum RAM = 1GB (4GB Recommended)"
echo "Minimum System Drive Free Space = 6GB"
echo ""
$SystemConfiguration | FT Name,ProcessorType,ProcessorSpeed_GHZ,SystemRAM_GB,SystemDriveFreeSpace_GB -Auto
