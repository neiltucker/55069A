Remove-Item -Recurse -Force $Labfiles\SQLServer\SQL2012 -ErrorAction SilentlyContinue
DisMount-Diskimage -DevicePath \\.\CDROM1 -ErrorAction SilentlyContinue
MD $Labfiles\SQLServer -ErrorAction SilentlyContinue
Mount-DiskImage $Labfiles\SQL2012.ISO | Get-DiskImage
Copy-Item -Path \\.\CDROM1\ -Destination $Labfiles\SQLServer -Recurse -Force -PassThru
DisMount-DiskImage -DevicePath \\.\CDROM1 -PassThru
Rename-Item $Labfiles\SQLServer\CDROM1 $Labfiles\SQLServer\SQL2012 -PassThru -Force
Remove-Item -Recurse -Force $Labfiles\AdventureWorks -ErrorAction SilentlyContinue
Get-ChildItem "$Labfiles\AdventureWorks 2012 OLTP Script.zip" | UnBlock-File
$Shell = New-Object -Com Shell.Application
$AWZip = $Shell.NameSpace("$Labfiles\AdventureWorks 2012 OLTP Script.zip")
ForEach ($Item in $AWZip.Items())
{
$Shell.NameSpace($Labfiles).CopyHere($Item)
}
Rename-Item "$Labfiles\AdventureWorks 2012 OLTP Script" $Labfiles\AdventureWorks -Force -ErrorAction SilentlyContinue